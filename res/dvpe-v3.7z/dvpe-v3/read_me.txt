=======================================
Extended Programmer Dvorak (dvpe) v0.3
=======================================

Done this work with "Windows Keyboard Layout Creator 1.4"

For more: https://github.com/district10/extended-programmer-dvorak


Gnat TANG
gnat_tang@yeah.net
March 4, 2014